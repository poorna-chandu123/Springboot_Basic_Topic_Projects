package com.Spring.SpringValidation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.SpringValidation.entity.User;
import com.Spring.SpringValidation.exception.UserNotFoundException;
import com.Spring.SpringValidation.repo.UserRepo;

import jakarta.transaction.Transactional;

@Service
public class UserServices {
	
	
	@Autowired
	private UserRepo repo;
	
	
	public  User saveUser(User user) {
		return repo.save(user);
		
	}

	
	
	public List<User> getALLUsers(){
		return repo.findAll();
		
	}
	
	
	public User getUser(int id) throws UserNotFoundException{
		User user =repo.findByuserID(id);
		if (user != null) {
			return user;
		}else {
			throw new UserNotFoundException("user not avalible id:"+ id);
		}
	}
}
