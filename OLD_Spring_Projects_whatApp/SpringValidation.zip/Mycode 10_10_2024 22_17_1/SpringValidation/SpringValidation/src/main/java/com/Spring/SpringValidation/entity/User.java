package com.Spring.SpringValidation.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "kesavareddy")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "emp_generator11")
    @SequenceGenerator(name = "emp_generator11", sequenceName = "uss_seq1", allocationSize = 1)
    private int userID;

    @Column(name = "USER_NAME")
    @NotBlank(message = "userName maniditory.....Ga evvali")
    private String userName;

    @Column(name = "EMAIL")
    @Email(message = " email correct format ....ledu")
    private String email;

    @Column(name = "MOBILENUB")
    @Pattern(regexp ="^\\d{10}$", message = "invalid mobile number")
    private String mobilenub;

    @Column(name = "AGE")
    @NotNull(message = "age is mandatory")
    @Min(value = 18, message = "Minimum age must be 18")
    @Max(value = 60, message = "Maximum age must be 60")
    private int age;

    @Column(name = "NATIONALITY")
    @NotBlank(message = "provide nationality.............")
    private String nationality;

    // Constructors, getters, and setters
    public User() {
    }

    public User(int userID, @NotBlank(message = "userName maniditory.....Ga evvali") String userName,
                @Email(message = " email correct format ....ledu") String email,
                @Pattern(regexp = "^\\d{10}$", message = "invalid mobile number") String mobilenub,
                @NotNull @Min(value = 18, message = "Minimum age must be 18") @Max(value = 60, message = "maximum age must be 60") int age,
                @NotBlank(message = "provide nationality.............") String nationality) {
        super();
        this.userID = userID;
        this.userName = userName;
        this.email = email;
        this.mobilenub = mobilenub;
        this.age = age;
        this.nationality = nationality;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobilenub() {
        return mobilenub;
    }

    public void setMobilenub(String mobilenub) {
        this.mobilenub = mobilenub;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
}
