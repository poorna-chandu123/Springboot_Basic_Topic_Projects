package com.Spring.SpringValidation.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Spring.SpringValidation.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {
	
	User findByuserID(int id);
	
//	User user = repo.findByUserID(id);

}
