package com.spring.One_one_Bi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.One_one_Bi.Entity.Employee;
import com.spring.One_one_Bi.Entity.Task;
import com.spring.One_one_Bi.Repo.EmpRepo;



@SpringBootApplication
public class OneOneBiApplication implements CommandLineRunner {

    @Autowired
    private EmpRepo repo;

    public static void main(String[] args) {
        SpringApplication.run(OneOneBiApplication.class, args);
        System.out.println("Running.......");
    }

    @Override
    public void run(String... args) throws Exception {
        Employee emp = new Employee("Naveen");
        Task tas1 = new Task("Java coding");
        emp.setTask(tas1);
        repo.save(emp);

        Employee emp1 = new Employee("Kiran");
        Task tas2 = new Task("Spring Boot coding");
        emp1.setTask(tas2);
        repo.save(emp1);
    }

}
