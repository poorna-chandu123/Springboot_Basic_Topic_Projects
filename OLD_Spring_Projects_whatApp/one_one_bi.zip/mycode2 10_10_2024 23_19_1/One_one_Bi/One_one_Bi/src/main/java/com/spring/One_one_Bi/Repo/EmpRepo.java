package com.spring.One_one_Bi.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.One_one_Bi.Entity.Employee;

public interface EmpRepo extends JpaRepository<Employee, Integer> {
}
