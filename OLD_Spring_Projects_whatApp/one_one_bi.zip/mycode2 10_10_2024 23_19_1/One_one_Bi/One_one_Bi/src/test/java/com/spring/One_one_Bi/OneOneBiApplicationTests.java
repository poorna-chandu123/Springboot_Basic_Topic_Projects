package com.spring.One_one_Bi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneOneBiApplicationTests {

	@Test
	void contextLoads() {
	}

}
