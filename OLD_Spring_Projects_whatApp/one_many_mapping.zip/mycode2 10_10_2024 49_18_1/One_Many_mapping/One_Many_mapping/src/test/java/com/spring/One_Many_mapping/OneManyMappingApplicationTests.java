package com.spring.One_Many_mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneManyMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
