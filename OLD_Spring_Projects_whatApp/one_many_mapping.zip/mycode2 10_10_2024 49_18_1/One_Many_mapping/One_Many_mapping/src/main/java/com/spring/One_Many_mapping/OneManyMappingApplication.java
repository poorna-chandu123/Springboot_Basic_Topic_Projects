package com.spring.One_Many_mapping;

import com.spring.One_Many_mapping.Entity.Empclass;
import com.spring.One_Many_mapping.Entity.Taskclass;
import com.spring.One_Many_mapping.Repo.Repointerface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;

@SpringBootApplication
public class OneManyMappingApplication implements CommandLineRunner {

    @Autowired
    private Repointerface repo;

    public static void main(String[] args) {
        SpringApplication.run(OneManyMappingApplication.class, args);
        System.out.println("Application is running...");
    }

    @Override
    public void run(String... args) throws Exception {
        Empclass emp = new Empclass("naven");
        Empclass emp1 = new Empclass("kiran");

        Taskclass ts = new Taskclass("jav");
        Taskclass ts1 = new Taskclass("orcle");
        Taskclass ts2 = new Taskclass("html");
        Taskclass ts3 = new Taskclass("css");
        Taskclass ts4 = new Taskclass("spring");
        Taskclass ts5 = new Taskclass("spring Boot");

        emp.getTask().addAll(Arrays.asList(ts, ts1, ts2, ts3));
        emp1.getTask().addAll(Arrays.asList(ts4, ts5));

        repo.save(emp);
        repo.save(emp1);
    }
}
