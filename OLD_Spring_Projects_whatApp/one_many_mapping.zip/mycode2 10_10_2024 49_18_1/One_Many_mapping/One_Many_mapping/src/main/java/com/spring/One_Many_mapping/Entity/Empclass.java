package com.spring.One_Many_mapping.Entity;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Emp_t1")
public class Empclass {

	 @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gen")
	    @SequenceGenerator(name = "gen", sequenceName = "seq1", allocationSize = 1)

	private Long empid;
	private String empname;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "empid")
	private List<Taskclass> task = new ArrayList<>();

	// Constructors, getters, and setters

	public Empclass() {
	}
	public Empclass(String empname) {
		this.empname = empname;

	}

	public Long getEmpid() {
		return empid;

	}
	public void setEmpid(Long empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;

	}
	public List<Taskclass> getTask() {
		return task;

	}
	public void setTask(List<Taskclass> task) {
		this.task = task;
	}

}