package com.spring.One_Many_mapping.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Task_e1")
public class Taskclass {

	 @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gggen")
	    @SequenceGenerator(name = "gggen", sequenceName = "sseq1", allocationSize = 1)
    private Long taskid;

    private String taskname;

    // Constructors, getters, and setters

    public Taskclass() {}

    public Taskclass(String taskname) {
        this.taskname = taskname;
    }

    public Long getTaskid() {
        return taskid;
    }

    public void setTaskid(Long taskid) {
        this.taskid = taskid;
    }

    public String getTaskname() {
        return taskname;
    }

    public void setTaskname(String taskname) {
        this.taskname = taskname;
    }
}
