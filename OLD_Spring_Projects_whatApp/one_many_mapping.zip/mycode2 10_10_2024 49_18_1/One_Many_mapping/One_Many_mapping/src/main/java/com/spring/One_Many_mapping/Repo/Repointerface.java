package com.spring.One_Many_mapping.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.One_Many_mapping.Entity.Empclass;

public interface Repointerface extends JpaRepository<Empclass, Integer> {

}
