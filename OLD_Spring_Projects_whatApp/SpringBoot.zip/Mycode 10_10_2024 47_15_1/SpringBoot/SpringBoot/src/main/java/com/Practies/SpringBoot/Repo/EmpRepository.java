package com.Practies.SpringBoot.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Practies.SpringBoot.Entity.EmpClass;



public interface EmpRepository extends JpaRepository<EmpClass, Long> {

}
