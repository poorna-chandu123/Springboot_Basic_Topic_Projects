package com.Practies.SpringBoot.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "EMPCLASS")
public class EmpClass {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "emp_class_seq_gen")
    @SequenceGenerator(name = "emp_class_seq_gen", sequenceName = "emp_class_seq", allocationSize = 1)
	@Column(name = "id")
 private int id;
	@Column(name = "FirstName")
	private String FirstName;

	@Column(name = "LastName")
	 private String LastName;
 
 public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getFirstName() {
	return FirstName;
}


public void setFirstName(String firstName) {
	FirstName = firstName;
}


public EmpClass(int id, String firstName, String lastName) {
	super();
	this.id = id;
	
	this.FirstName = firstName;
	this.LastName = lastName;
}

public EmpClass() {  // get cheyataniki  default constructor vundali lekunte result radu
}


public String getLastName() {
	return LastName;
}


public void setLastName(String lastName) {
	LastName = lastName;
}



}


