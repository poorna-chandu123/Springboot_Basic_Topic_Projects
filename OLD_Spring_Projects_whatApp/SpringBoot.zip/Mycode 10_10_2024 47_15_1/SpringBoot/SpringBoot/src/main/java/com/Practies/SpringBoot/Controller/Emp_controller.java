package com.Practies.SpringBoot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Practies.SpringBoot.Entity.EmpClass;
import com.Practies.SpringBoot.Repo.EmpRepository;



@RestController
@RequestMapping("/emp")
public class Emp_controller {

    @Autowired
    private EmpRepository repo;

    @PostMapping("/save")
    public EmpClass saveEmp(@RequestBody EmpClass empClass) {
        return repo.save(empClass);
    }

    @GetMapping("/getAll")
    public List<EmpClass> getAllEmp() {
        return repo.findAll();
    }

    @GetMapping("/basedempid/{id}")
    public EmpClass getEmpById(@PathVariable int id) {
        return repo.findById((long) id).orElse(null);
    }
}
