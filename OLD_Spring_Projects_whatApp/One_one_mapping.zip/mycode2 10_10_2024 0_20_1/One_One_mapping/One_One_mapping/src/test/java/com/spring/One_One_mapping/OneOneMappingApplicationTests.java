package com.spring.One_One_mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneOneMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
