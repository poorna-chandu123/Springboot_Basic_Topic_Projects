package com.spring.One_One_mapping.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.spring.One_One_mapping.Entity.Employee;

public interface EmpRepo extends JpaRepository<Employee, Integer> {
}
