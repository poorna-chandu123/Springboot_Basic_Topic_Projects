package com.spring.One_One_mapping.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "emp_table")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "emp_gen")
    @SequenceGenerator(name = "emp_gen", sequenceName = "emp_seq1", allocationSize = 1)
    private int EmpID;
    private String EmpName;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "TaskId")
    private Task task;

    public Employee() {
    }

    public Employee(String empName) {
        EmpName = empName;
    }

    public int getEmpID() {
        return EmpID;
    }

    public void setEmpID(int empID) {
        EmpID = empID;
    }

    public String getEmpName() {
        return EmpName;
    }

    public void setEmpName(String empName) {
        EmpName = empName;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }
}
