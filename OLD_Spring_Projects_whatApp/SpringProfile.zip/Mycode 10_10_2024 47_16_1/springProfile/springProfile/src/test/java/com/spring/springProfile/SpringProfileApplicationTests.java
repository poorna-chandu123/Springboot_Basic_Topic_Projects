package com.spring.springProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
