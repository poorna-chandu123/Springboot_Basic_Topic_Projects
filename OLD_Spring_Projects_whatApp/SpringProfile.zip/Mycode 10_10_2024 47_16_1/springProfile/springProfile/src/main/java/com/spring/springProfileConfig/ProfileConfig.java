package com.spring.springProfileConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.spring.springProfile.SpringProfileApplication;

@Configuration
public class ProfileConfig {
	
	private static Logger LOGGER =LoggerFactory.getLogger(ProfileConfig.class);

// @profile annotation is used to conditionally active /register
	
	// Used to develop an "if-then-else" conditional checking to configure
	
	// Allows to register beans by condition
	
	@Profile("local")
    @Bean
    public String localConfig() {
        LOGGER.info("local environment run avuthundi...............");
        return "localConfig";
    }

    @Profile("dev")
    @Bean
    public String devConfig() {
        LOGGER.info("dev environment run avuthundi...............");
        return "devConfig";
    }

    @Profile("qa")
    @Bean
    public String qaConfig() {
        LOGGER.info("QA environment run avuthundi...............");
        return "qaConfig";
    }

    @Profile("prod")
    @Bean
    public String prodConfig() {
        LOGGER.info("prod environment run avuthundi...............");
        return "prodConfig";
    }
}
