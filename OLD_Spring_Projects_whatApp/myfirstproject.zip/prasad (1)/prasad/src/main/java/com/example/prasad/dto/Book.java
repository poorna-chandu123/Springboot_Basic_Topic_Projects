package com.example.prasad.dto;

public class Book {
	private int id;
	private String book_name;
	
	public void setId(int id) {
		this.id = id;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public String getBook_name() {
		return book_name;
	}

	public String getDescription() {
		return description;
	}

	private String description;
	
	public Book(int id, String book_name, String description) {
		this.id = id;
		this.book_name = book_name;
		this.description = description;
	}
	
	
	

}
