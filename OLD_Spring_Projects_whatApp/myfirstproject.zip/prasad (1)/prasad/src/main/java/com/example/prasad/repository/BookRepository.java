package com.example.prasad.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.prasad.entity.BookEntity;

public interface BookRepository extends JpaRepository<BookEntity,Long> {

	
	
}
