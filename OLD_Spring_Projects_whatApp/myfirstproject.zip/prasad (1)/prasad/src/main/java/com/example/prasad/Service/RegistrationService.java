package com.example.prasad.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.prasad.dto.RegistrationDto;
import com.example.prasad.entity.RegistrationEntity;
import com.example.prasad.repository.DeleteById;
import com.example.prasad.repository.FindByIdRepository;
import com.example.prasad.repository.RegistrationRepository;

@Service
public class RegistrationService implements RegistrationInterface{
	@Autowired
	private RegistrationRepository registrationRepository;
	@Autowired
	private FindByIdRepository findByIdRepository;
	@Autowired
	private DeleteById deleteById;
	
	public String saveRegistrationDetails(RegistrationDto registrationDto) {
		RegistrationEntity registrationEntity=new RegistrationEntity();
		registrationEntity.setFname(registrationDto.getFname());
		registrationEntity.setSurname(registrationDto.getSurname());
		registrationEntity.setGmail(registrationDto.getGmail());
		registrationEntity.setGender(registrationDto.getGender());
		registrationEntity.setPassword(registrationDto.getPassword());
		registrationEntity.setUsername(registrationDto.getUsername());
		registrationEntity.setId((int)registrationDto.getId());
			RegistrationEntity savaregistration=registrationRepository.save(registrationEntity);
	
	  String status=null;
		if(savaregistration==null)
		{
			status="data not insert ";
		}
		else
		{
			status="data insert sucessfull";
		}
		return status;
	}

	public RegistrationDto findbyid(long id) throws Exception
	{
		RegistrationEntity registrationEntity=findByIdRepository.getById(id);
		RegistrationDto registrationDto=null;
		if(null!=registrationEntity)
		{
			registrationDto=new RegistrationDto();
			registrationDto.setId(registrationEntity.getId());
			registrationDto.setFname(registrationEntity.getFname());
			registrationDto.setSurname(registrationEntity.getSurname());
			registrationDto.setGender(registrationEntity.getGender());
			registrationDto.setGmail(registrationEntity.getGmail());
			registrationDto.setUsername(registrationEntity.getUsername());
			registrationDto.setPassword(registrationEntity.getPassword());
		}
		else
		{
			throw new Exception("given by id there is no existing data in table"+id);
		}
		return registrationDto;
	}

	
	public String saveAllData(List<RegistrationEntity> registrationEntity) {
		List<RegistrationEntity> response = (List<RegistrationEntity>) registrationRepository.saveAll(registrationEntity);
		String status=null;
		if(response!=null)
		{
			status="data is insert sucessfull";
		}
		else
		{
			status="data are not insert";
		}
		return status;
		
	}

	public List<RegistrationEntity> getDetails() {
		List<RegistrationEntity> response=registrationRepository.findAll();
		
		return response;
	}

	public void deleteById(Long id) 
	{
		 deleteById.deleteById(id);
		
	}

	public ResponseEntity<RegistrationEntity> putmapping(long id, RegistrationDto registrationDto) {
		
		// RegistrationEntity registrationEntity=new RegistrationEntity();
		//RegistrationEntity registrationEntity=findByIdRepository.getById(id).orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id: " + id));

 
		try
		{
			
		RegistrationEntity registrationEntity=findByIdRepository.getById(id);
		registrationEntity.setFname(registrationDto.getFname());
		registrationEntity.setPassword(registrationDto.getPassword());
		registrationEntity.setSurname(registrationDto.getSurname());
		
		//return ResponseEntity.ok(registrationEntity);
		return new ResponseEntity<RegistrationEntity>(registrationRepository.save(registrationEntity), HttpStatus.OK);

		}
		catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	public void patchmapping(long id, String gmail) {
		// TODO Auto-generated method stub
		RegistrationEntity registrationEntity=findByIdRepository.getById(id);
		registrationEntity.setGmail(gmail);
		registrationRepository.save(registrationEntity);
	}

	
	public List<RegistrationEntity> findByfname(String gmail) {
		// TODO Auto-generated method stub
	var response=(List<RegistrationEntity>)findByIdRepository.findByGmail(gmail);
	 return response;
	}

	public List<RegistrationEntity> findbygmailgender(String gmail, String gender) {
		var response=(List<RegistrationEntity>)findByIdRepository.findByGmailAndGender(gmail,gender);
		return response;
	}

	public List<RegistrationEntity> findBymobile(String mobile) {
		// TODO Auto-generated method stub
		return (List<RegistrationEntity>)findByIdRepository.findByPassword(mobile);
	}

	public List<RegistrationEntity> findbydistanctgmails(String gmail) {
		
		return (List<RegistrationEntity>) findByIdRepository.findDistinctByGmail(gmail);
	}

	public List<RegistrationEntity> findByNameLike(String ch) {
		
		return (List<RegistrationEntity>)findByIdRepository.findByFnameLike(ch);
	}

	public Optional<RegistrationEntity> getUserById(long id) {
		// TODO Auto-generated method stub
		return findByIdRepository.findById(id);
	}

	public Optional<RegistrationEntity> findById(Long id) {
		// TODO Auto-generated method stub
		return findByIdRepository.findById(id);
	}

	

	
	}