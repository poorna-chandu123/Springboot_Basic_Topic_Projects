package com.example.prasad.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.prasad.entity.RegistrationEntity;

public interface RegistrationRepository extends JpaRepository<RegistrationEntity,Long>{

	
}
