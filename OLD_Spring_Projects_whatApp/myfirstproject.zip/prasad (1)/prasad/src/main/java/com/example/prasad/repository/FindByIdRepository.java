package com.example.prasad.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.prasad.entity.RegistrationEntity;

public interface FindByIdRepository extends JpaRepository<RegistrationEntity, Long> {

	List<RegistrationEntity> findByGmail(String gmail);


	List<RegistrationEntity> findByGmailAndGender(String gmail, String gender);


	List<RegistrationEntity> findByPassword(String mobile);


	List<RegistrationEntity> findDistinctByGmail(String gmail);


	List<RegistrationEntity> findByFnameLike(String ch);


  

	

}
