package com.example.prasad.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.prasad.Service.RegistrationService;
import com.example.prasad.Service.Serviceprasad;
import com.example.prasad.dto.RegistrationDto;
import com.example.prasad.entity.RegistrationEntity;

import jakarta.persistence.EntityNotFoundException;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ControllerPrasad {
	
	@Autowired
	Serviceprasad serviceprasad;
	@Autowired
	private RegistrationService registrationService;
	
	
	@GetMapping("/book")
	public String Book()
	{
		return "this is a book";
				
	}
	/*@PostMapping("/savebook")
	public String savebook(@RequestBody Book book)
	{
		return "prasad";
	}*/
	@PostMapping("/registration")
	public String saveregistration(@RequestBody RegistrationDto registrationDto)
	{
		return  registrationService.saveRegistrationDetails(registrationDto);
	}
	/*@GetMapping("/userlogin/{username}")
	public String userLogin(@PathVariable String username)
	{
		
		return registrationService.userlogin(username);
	}*/
	@GetMapping("/findbyid/{id}")
	public ResponseEntity<Optional<RegistrationEntity>> findbyid(@PathVariable long  id) throws Exception
	{
		//return registrationService.findbyid(id);
		 try {
			 Optional<RegistrationEntity>  user = registrationService.getUserById(id);
	            return ResponseEntity.ok(user);
	        } catch (EntityNotFoundException e) {
	            // Handle the case when the user is not found
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	}
	
	
	//get user detials from database if user not found i am handle exception
	@GetMapping("/getbyuserid/{id}")
	public RegistrationEntity getRegistrationEntityById(@PathVariable long id) {
//		 try {
//		        RegistrationEntity registrationEntity = registrationService.findById(id)
//		                .orElseThrow(() -> new EntityNotFoundException("RegistrationEntity not found with id: " + id));
//		        
//		        return ResponseEntity.ok(registrationEntity);
//		    } catch (EntityNotFoundException ex) {
//		        // Log the exception for debugging purposes
//		        ex.printStackTrace();
//
//		        // Return a custom error response
//		        CustomErrorResponse errorResponse = new CustomErrorResponse(
//		                HttpStatus.NOT_FOUND.value(),
//		                ex.getMessage(),
//		                System.currentTimeMillis());
//
//		        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
//		    }
//		
		
	    return registrationService.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("RegistrationEntity not found with id: " + id));
	}

	
	
	@PutMapping("modified/{id}")
	public ResponseEntity<RegistrationEntity> userdatamodification(@PathVariable long id,@RequestBody RegistrationDto registrationDto) 
	{
		return 	registrationService.putmapping(id,registrationDto);
		
	}
	
	
	
	@PostMapping("/saveall")
	public String  saveAllStudents(@RequestBody List<RegistrationEntity> registrationEntity) {
		 
	return registrationService.saveAllData(registrationEntity);
	}
	
	
	
	@GetMapping("/getall")
	public List<RegistrationEntity> getdetails()
	{
		List<RegistrationEntity> response=registrationService.getDetails();
		return response;
	}
	
	
	
	@DeleteMapping("/deletebyid/{id}")
	public String deleteById(@PathVariable Long id) 
	{
	    	registrationService.deleteById(id);
	        return "data is delete sucessful";
	}
	
	@PatchMapping("/specificdata/{id}/{gmail}")
	public String patchMapping(@PathVariable long id,@PathVariable String gmail)
	{
		 registrationService.patchmapping(id,gmail);
		 return "update sucessful";
	}
	
	
	
	@GetMapping("/querymethods/{fname}")
	public List<RegistrationEntity> findByfname(@RequestParam String fname)
	{
		return  registrationService.findByfname(fname);
	}
	
	
	
	
     @GetMapping("/findbygmail/{gmail}")
     public List<RegistrationEntity> firstname(@PathVariable String gmail)
     {
    var response=(List<RegistrationEntity>)registrationService.findByfname(gmail);
    	 return response;
     }
     @GetMapping("/findbygmailgender/{gmail}/{gender}")
     public List<RegistrationEntity> findbygmailgender(@PathVariable String gmail,@PathVariable String gender)
     {
    	 var response=(List<RegistrationEntity>)registrationService.findbygmailgender(gmail,gender);
    	 return response;
     }
     @GetMapping("/distanctgmail/{gmail}")
     public List<RegistrationEntity> distanctgmails(@PathVariable String gmail)
     {
    	var response=(List<RegistrationEntity>)registrationService.findbydistanctgmails(gmail); 
    	return response;
     }
     @GetMapping("/findbypassword/{password}")
     public List<RegistrationEntity> firstmobile(@PathVariable String password)
     {
        var response=(List<RegistrationEntity>)registrationService.findBymobile(password);
    	 return response;
     }
     @GetMapping("/findByNameLike/{ch}")
     public List<RegistrationEntity> findByNameLike(@PathVariable String ch)
     {
         var response=(List<RegistrationEntity>)registrationService.findByNameLike(ch);
         return response;
 
     }
     
}
