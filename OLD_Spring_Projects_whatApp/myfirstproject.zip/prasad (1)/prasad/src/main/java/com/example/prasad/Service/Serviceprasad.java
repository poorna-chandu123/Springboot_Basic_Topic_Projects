package com.example.prasad.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.prasad.dto.Book;
import com.example.prasad.entity.BookEntity;
import com.example.prasad.repository.BookRepository;

@Service
public class Serviceprasad {
	@Autowired
	private BookRepository bookRepository;
	
	public String savedetails(Book book)
	{
		BookEntity bookEntity=new BookEntity();
		bookEntity.setId(book.getId());
		bookEntity.setBook_name(book.getBook_name());
		bookEntity.setDescription(book.getDescription());
		BookEntity savebook=bookRepository.save(bookEntity);
		String status = null;
		if (savebook == null) {
			status = "Data is not saved ,due to some issue";
		} else {
			status = "Data is saved successfully";
		}
		return status;

	}
	

}
