package com.example.prasad.entity;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "registration")
public class RegistrationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int  id;

	@Column(name = "fname")
	public String fname;
	
	@Column(name = "sname")
	public String surname;
	
	@Column(name = "gmail")
	public String gmail;
	
	@Column(name="username")
	private String username;
	
	@Column(name = "password")
	public String password;
	
	
	@Column(name = "gender")
	public String gender;


	public int getId() {
		return id;
	}


	public void setId(int l) {
		this.id = l;
	}
	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getSurname() {
		return surname;
	}


	public void setSurname(String surname) {
		this.surname = surname;
	}


	public String getGmail() {
		return gmail;
	}


	public void setGmail(String gmail) {
		this.gmail = gmail;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public RegistrationEntity orElseThrow(Object object) {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	}
