package com.example.prasad.Service;

import java.util.List;

import com.example.prasad.entity.RegistrationEntity;

public interface RegistrationInterface {
	public String saveAllData(List<RegistrationEntity> registratoinEntity);
	public List<RegistrationEntity> getDetails();

}
