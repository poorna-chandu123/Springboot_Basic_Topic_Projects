package com.example.prasad.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.prasad.entity.RegistrationEntity;

@Repository
public interface PrasadRepository extends JpaRepository<RegistrationEntity, Long> {

}
