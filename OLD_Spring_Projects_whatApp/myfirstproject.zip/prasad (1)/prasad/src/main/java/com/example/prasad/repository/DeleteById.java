package com.example.prasad.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.prasad.entity.RegistrationEntity;

public interface DeleteById extends JpaRepository<RegistrationEntity, Long>  {

}
